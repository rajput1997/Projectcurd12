﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PorjectMvc.Models
{
    public class Customer
    {
        public int Id { get; set; }
        public string Nmae { get; set; }

        public string Email { get; set; }

        public  string Mobile {  get; set; }

        public string Gender { get; set; }


        public Location  Location { get; set; }

    }
}
