﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PorjectMvc.Models
{
    public class CustomerDb
    {
        private List<Customer> Customers;
        public CustomerDb()
        {
            Customers = new List<Customer>()
            {
          new Customer() {Id=1,Nmae="Rohit",Email="Raj@gmail.com",Mobile="984377223",Gender="Male" },
          new Customer() {Id=2,Nmae="mohit",Email="Mohit@gmail.com",Mobile="985677223",Gender="Male" },
          new Customer() {Id=3,Nmae="sohit",Email="sohit@gmail.com",Mobile="974677223",Gender="Male" },
          new Customer() {Id=4,Nmae="Rajat",Email="Rajat@gmail.com",Mobile="964677223",Gender="Male" },

            };
        }
        public List<Customer> GetCustomers()
        {
            return this.Customers;
        }
        public Customer AddCustomer(Customer obj)
        {
            this.Customers.Add(obj);
            return obj;
        }
    }
}
