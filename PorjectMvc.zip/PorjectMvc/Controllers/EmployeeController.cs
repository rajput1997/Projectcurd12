﻿using Microsoft.AspNetCore.Hosting;

using Microsoft.AspNetCore.Mvc;
using PorjectMvc.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace PorjectMvc.Controllers
{
    public class EmployeeController : Controller
    {
        private AppDbContext dbContext;

        public IHostingEnvironment Environment { get; }

        public EmployeeController(AppDbContext context, IHostingEnvironment environment)
        {
            dbContext = context;
            Environment = environment;
        }
        public IActionResult Index()
        {
            var emps = dbContext.Employee.ToList();
           
            return View(emps);
        }
        
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Create(Employee employee)
        {
            

            var files= Request.Form.Files;
            string dbPath = string.Empty;

            if(files.Count>0)
            {
                string path = Environment.WebRootPath;
                string fullpath = Path.Combine(path, "Images", files[0].FileName);

                dbPath = "Images/" + files[0].FileName;

                FileStream stream = new FileStream(fullpath,FileMode.Create);
                files[0].CopyTo(stream);
            }
            employee.Image = dbPath;

            dbContext.Employee.Add(employee);
            dbContext.SaveChanges();

            return RedirectToAction("Index");
        }
        public IActionResult Details()
        { 
            return View();
        }
    }
}
