﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using PorjectMvc.Models;

namespace PorjectMvc.Controllers
{
	public class CustomerController : Controller
	{
		private AppDbContext dbContext;
	   // private CustomerDb db;  use the without sql server data than use this line

		public CustomerController(AppDbContext _dbContext)
		{
		   // db = new CustomerDb();

			dbContext = _dbContext;
		}
		public IActionResult Index()
		{
			//var customers = dbContext.customers.ToList(); 
			// var customers = db.GetCustomers();
			var locations = dbContext.Location.ToList();

			return View(locations);
		}
        public IActionResult CustomerList(int id)
        {
			var customers = dbContext.customers.Where(e => e.Location.Id == id);

			return View(customers);
        }

		public IActionResult CustomerDetails(int id)
		{
			var customer = dbContext.customers.SingleOrDefault(e => e.Location.Id == id);

			return View(customer);
		}
	}
}
